package cardatausage_Vehicle;

import java.io.File;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import CarDataPages.CreateCampaignPages;
import CarDataPages.VehiclePageObjects;
import cardatausage_Base.BaseClass;
import cardatausage_Base.LocType;


public class VehiclePageTest extends BaseClass{
	static String file=System.getProperty("user.dir")+"\\TestData\\sampletest.xlsx";
	static String vehicleScreenURL="https://cc-system-web-staging.apps.stage-eu.kamereon.io/vehicle";
	
	@Test(priority=28)
	public void vehicleTab_Base() throws IOException{
		
	    driver.get(vehicleScreenURL);
	    pause(6000);
		click(LocType.xpath, VehiclePageObjects.searchAVin_Xpath); 
		DTA_SendKeys(LocType.xpath, VehiclePageObjects.searchAVin_Xpath, excel(file,0, 1, 0));
		click(LocType.xpath,VehiclePageObjects.SelectAConfigFile_Xpath);
		scrollINElement("#cdk-overlay-0 > div > div", 250);
		click(LocType.xpath, "//mat-option[@id='mat-option-7']/span");
	    click(LocType.xpath,VehiclePageObjects.search_Xpath);
	    pause(6000);
		getText(LocType.xpath,VehiclePageObjects.BlackListedVINResultText_Xpath);
			}
	 
	@Test(priority=29)
	
	   public void searchBlackListedVin_Vehicle() throws Throwable{
		 
		 driver.get(vehicleScreenURL);
		 pause(6000);
			click(LocType.xpath, VehiclePageObjects.searchAVin_Xpath); 
			//Sending a Blacklisted VIN
			pause(6000);
			DTA_SendKeys(LocType.xpath, VehiclePageObjects.searchAVin_Xpath, excel(file,0, 1, 0));
			click(LocType.xpath,VehiclePageObjects.search_Xpath);
			cropImage(VehiclePageObjects.RedWarningBox_xpath,"BlackListedVINWarningMSG");
			pause(6000);
			getText(LocType.xpath,VehiclePageObjects.VehicleUsedinCampaign_xpath);
			click(LocType.xpath,VehiclePageObjects.ACTIONSbutton_Xpath);
			getText(LocType.xpath,VehiclePageObjects.BlackListedVINHeaderText_Xpath);
	}			
	  
@Test(priority=30)

    public void  searchValidVIN_VehicleAndValidateSearchResultHeaders( ) throws Throwable{
	 driver.get(vehicleScreenURL);
	click(LocType.xpath, VehiclePageObjects.searchAVin_Xpath);
	DTA_SendKeys(LocType.xpath, VehiclePageObjects.searchAVin_Xpath, excel(file,0, 2, 0));
	click(LocType.xpath,VehiclePageObjects.search_Xpath);
	pause(6000);
	getText(LocType.xpath,VehiclePageObjects.VehicleUsedinCampaign_xpath);
	String CampaignName_Title =getText(LocType.xpath,VehiclePageObjects.CampaignNameTitle_xpath);
	Assert.assertEquals(CampaignName_Title, "Campaign name");
	String FleetName_Title =getText(LocType.xpath,VehiclePageObjects.FleetNameTitle_xpath);
	Assert.assertEquals(FleetName_Title, "Fleet name");
	String Configfile_Title =getText(LocType.xpath,VehiclePageObjects.ConfigFileTitlexpath);
	Assert.assertEquals(Configfile_Title, "Config File" );
    String VinAssociation_Title =getText(LocType.xpath,VehiclePageObjects.VINAssociationTitle_xpath);
	Assert.assertEquals(VinAssociation_Title, "VIN Association");
    String VINActivation_Title =getText(LocType.xpath,VehiclePageObjects.VINActivationTitle_xpath);
	Assert.assertEquals(VINActivation_Title, "VIN Activation"); 
	getText(LocType.xpath,VehiclePageObjects.VinAssociatedconfigfile_xpath);
	getText(LocType.xpath,VehiclePageObjects.AssociationStatus_xpath);
	
	}

@Test(priority = 31)
public void searchVINInformationToIdentifyStatus() throws IOException{
	driver.get(vehicleScreenURL);
	click(LocType.xpath, VehiclePageObjects.searchAVin_Xpath); 
	DTA_SendKeys(LocType.xpath, VehiclePageObjects.searchAVin_Xpath, excel(file,0, 2, 0));
	click(LocType.xpath,VehiclePageObjects.search_Xpath);
	getText(LocType.xpath,VehiclePageObjects.VINinsearchresult_xpath);
	pause(6000);
	getText(LocType.xpath,VehiclePageObjects.VehicleUsedinCampaign_xpath);
	pause(6000);
	click(LocType.xpath,VehiclePageObjects.LaunchedButton_xpath);
	pause(6000);
	click(LocType.xpath,VehiclePageObjects.SavedButton_xpath);
	pause(6000);
	click(LocType.xpath,VehiclePageObjects.StoppedButton_xpath);
	cropImage(VehiclePageObjects.CampaignsStatusbuttonsColor_xpath,"ColouredLegendforCampaignStatus");
	}
	

	
	
@Test(priority=32,dependsOnMethods="searchBlackListedVin_Vehicle")
public void searchVINAndGetAssociatedCampaignsAndFleets() {
	String Actual_Title=getText(LocType.xpath,VehiclePageObjects.CampaignNameLink_xpath);
	pause(6000);
	click(LocType.xpath,VehiclePageObjects.CampaignNameLink_xpath);
	pause(6000);
	String Expected_Title=getText(LocType.xpath,VehiclePageObjects.CampaignTitle_xpath);
	pause(6000);
	Assert.assertEquals(Actual_Title,"Camp36" );
	click(LocType.xpath,VehiclePageObjects.FleetNameLink_xpath);
	getText(LocType.xpath,VehiclePageObjects.FleetTitle_xpath);
    String Total_AssociatedVINs=getText(LocType.xpath,VehiclePageObjects.TotalofAssociatedVINs);

}


}























