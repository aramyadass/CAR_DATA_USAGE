package cardatausage_ConfigFiles;

import java.io.IOException;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import CarDataPages.ConfigFilesPageObjects;
import CarDataPages.CreateCampaignPages;
import CarDataPages.EditFleetPageObjects;
import cardatausage_Base.BaseClass;
import cardatausage_Base.LocType;

public class ConfigFilePageTest extends BaseClass{
	static String file1 = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInputfleet.xlsx";

	@Test
	 
	public void addConfigFiles() throws IOException{
		
		click(LocType.xpath,ConfigFilesPageObjects.ConfigFilesTab_Xpath);
		click(LocType.xpath,ConfigFilesPageObjects.enterConfigFileName_Xpath);
		enterText(ConfigFilesPageObjects.enterConfigFileName_Xpath,excel(file1,0, 1, 0));
		enterText(ConfigFilesPageObjects.enterUID_Xpath,excel(file1,0, 1, 1)+""+getTimeStamp());
	}
}
