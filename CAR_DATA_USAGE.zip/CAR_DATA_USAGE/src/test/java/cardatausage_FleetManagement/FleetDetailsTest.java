package cardatausage_FleetManagement;

import cardatausage_Base.BaseClass;

public class FleetDetailsTest extends BaseClass{
	static String file = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInput.xlsx";
	static String file1 = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInputfleet.xlsx";
	static String FleetManagementScreenURL="https://cc-system-web-staging.apps.stage-eu.kamereon.io/fleets";
	
	
	
}
