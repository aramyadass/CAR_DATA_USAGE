package cardatausage_FleetManagement;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import CarDataPages.CreateCampaignPages;
import CarDataPages.EditFleetPageObjects;
import cardatausage_Base.BaseClass;
import cardatausage_Base.LocType;

public class EditFleetsTest extends BaseClass{
	static String file = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInput.xlsx";
	static String file1 = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInputfleet.xlsx";
	static String FleetManagementScreenURL="https://cc-system-web-staging.apps.stage-eu.kamereon.io/fleets";
	static String CampaignsScreenURL= "https://cc-system-web-staging.apps.stage-eu.kamereon.io/campaigns";
	SoftAssert a = new SoftAssert();

	@Test (priority=20)
	public void editLaunchedFleet(){
		// Assignee = Ramya - Z030183- 13/10/2020- Editing the Already Launched Fleet(Campname, Contxet planduration and save)
		
		implicitWait();
		try {
			driver.get(FleetManagementScreenURL);
			click(LocType.xpath,EditFleetPageObjects.fleetNamelink_xpath);
			//Use Assertflase  to verify whether Campname changed
			String Actual_fleetname=	getText(LocType.cssSelector,EditFleetPageObjects.fleetNameinpageheader_css);
			clear(LocType.xpath,EditFleetPageObjects.fleetCampaignname_xpath);
			enterText(EditFleetPageObjects.fleetCampaignname_xpath,excel(file, 0, 1, 0) +""+getTimeStamp());
			String Edited_FleetName=getText(LocType.xpath,EditFleetPageObjects.fleetCampaignname_xpath);
			a.assertTrue(Actual_fleetname.equalsIgnoreCase(Edited_FleetName));
			a.assertAll();
			clear(LocType.xpath,EditFleetPageObjects.fleetCampaignContext_xpath);
			enterText(EditFleetPageObjects.fleetCampaignContext_xpath, excel(file, 0, 1, 2));
			clear(LocType.xpath,EditFleetPageObjects.FleetNumberofactiveVINS_xpath);
			enterText(EditFleetPageObjects.FleetNumberofactiveVINS_xpath, excel(file, 0, 1, 1));
			btnClick(EditFleetPageObjects.SaveFleetButton_xpath);
			
			
		}
		catch(Exception e) {
			
		}
	}
	
	


	
	@Test(priority=21)
	public void editFleet_AddingAlreadyusedVIN() throws IOException{
		// Assignee = Ramya - Z030183- 14/10/2020- Editing the Already Launched Fleet with new set of Fleet information with Already used Vin 
		 
		implicitWait();
		driver.get(FleetManagementScreenURL);
		click(LocType.xpath,EditFleetPageObjects.EditFleet_xpath);
		clear(LocType.xpath,EditFleetPageObjects.fleetCampaignname_xpath);
		enterText(EditFleetPageObjects.fleetCampaignname_xpath,excel(file, 0, 1, 0) +""+getTimeStamp());
	    clear(LocType.xpath,EditFleetPageObjects.fleetCampaignContext_xpath);
		enterText(EditFleetPageObjects.fleetCampaignContext_xpath, excel(file, 0, 1, 2));
		clear(LocType.xpath,EditFleetPageObjects.FleetNumberofactiveVINS_xpath);
		enterText(EditFleetPageObjects.FleetNumberofactiveVINS_xpath, excel(file, 0, 1, 1));
		btnClick(EditFleetPageObjects.AddVINSButton_xpath);
		pause(5000);
		//uploadFileAutoit("C:\\Users\\z030183\\eclipse-workspace\\CAR_DATA_USAGE\\VF1RJA00960487720.csv");
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\VINfile.exe");
		scrollPageBy(0,1000);
        cropImage(EditFleetPageObjects.AlreadyusedwarningMsg_xpath,"editFleetWarningMessage");
		pause(5000);
		btnClick(EditFleetPageObjects.SaveFleetButton_xpath);
		click(LocType.xpath,EditFleetPageObjects.EditFleetaftersavebutton_xpath);
		
		
		
	}
	@Test(priority=22)
	
	public void editFleet_AddingBlackListedVIN() throws IOException{
		// Assignee = Ramya - Z030183- 14/10/2020- Editing with Blacklisted vin Launched Fleet with new set of Fleet information with Already used Vin 
		
		clear(LocType.xpath,EditFleetPageObjects.fleetCampaignname_xpath);
		enterText(EditFleetPageObjects.fleetCampaignname_xpath,excel(file, 0, 1, 0) +""+getTimeStamp());
	    clear(LocType.xpath,EditFleetPageObjects.fleetCampaignContext_xpath);
		enterText(EditFleetPageObjects.fleetCampaignContext_xpath, excel(file, 0, 1, 2));
		clear(LocType.xpath,EditFleetPageObjects.FleetNumberofactiveVINS_xpath);
		enterText(EditFleetPageObjects.FleetNumberofactiveVINS_xpath, excel(file, 0, 1, 1));
		btnClick(EditFleetPageObjects.AddVINSButton_xpath);
		pause(5000);
		//uploadFileAutoit("C:\\Users\\z030183\\eclipse-workspace\\CAR_DATA_USAGE\\VF1RJA00960487720.csv");
	Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\BlacklistedVIN.exe");
		pause(5000);
		scrollPageBy(0,1000);cropImage(EditFleetPageObjects.Blacklistedwarningmsg_xpath,"editFleetBlacklistedWarningMessage");
		
		pause(5000);
		btnClick(EditFleetPageObjects.SaveFleetButton_xpath);
		
	}
		
	@Test(priority=23)
	// Assignee = Ramya - Z030183- 15/10/2020- Editing the fleet and sycn Association's
	public void editFleetAndSyncAssociation() throws Throwable{
		click(LocType.xpath,EditFleetPageObjects.EditFleetaftersavebutton_xpath);
		clear(LocType.xpath,EditFleetPageObjects.fleetCampaignname_xpath);
		enterText(EditFleetPageObjects.fleetCampaignname_xpath,excel(file, 0, 1, 0) +""+getTimeStamp());
	    clear(LocType.xpath,EditFleetPageObjects.fleetCampaignContext_xpath);
		enterText(EditFleetPageObjects.fleetCampaignContext_xpath, excel(file, 0, 1, 2));
		clear(LocType.xpath,EditFleetPageObjects.FleetNumberofactiveVINS_xpath);
		enterText(EditFleetPageObjects.FleetNumberofactiveVINS_xpath, excel(file, 0, 1, 1));
		btnClick(EditFleetPageObjects.AddVINSButton_xpath);
		pause(7000);
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\ValidVin.exe");
		pause(5000);
		scrollPageBy(0,1000);cropImage(EditFleetPageObjects.messageafteraddingvlidvin,"ValidVINWaringMessage");
		pause(5000);
		btnClick(EditFleetPageObjects.SaveFleetButton_xpath);
		click(LocType.xpath,EditFleetPageObjects.SyncAssociationbutton_xpath);
		getText(LocType.xpath,EditFleetPageObjects.TotalNoofAssociatedVINS_xpath);
	}
	
	@Test(priority = 24)
	public void editFleetAndRemoveVINS() throws Throwable{
	
		implicitWait();
		driver.get(FleetManagementScreenURL);
		click(LocType.xpath,EditFleetPageObjects.EditFleet_xpath);
		clear(LocType.xpath,EditFleetPageObjects.fleetCampaignname_xpath);
		enterText(EditFleetPageObjects.fleetCampaignname_xpath,excel(file, 0, 1, 0) +""+getTimeStamp());
	    clear(LocType.xpath,EditFleetPageObjects.fleetCampaignContext_xpath);
		enterText(EditFleetPageObjects.fleetCampaignContext_xpath, excel(file, 0, 1, 2));
		clear(LocType.xpath,EditFleetPageObjects.FleetNumberofactiveVINS_xpath);
		enterText(EditFleetPageObjects.FleetNumberofactiveVINS_xpath, excel(file, 0, 1, 1));
		btnClick(EditFleetPageObjects.RemoveVINSButton_xpath);
		pause(5000);
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\VINfile.exe");
		scrollPageBy(0,1000);
        cropImage(EditFleetPageObjects.AlreadyusedwarningMsg_xpath,"RemoveFleetWarningMessage");
		pause(5000);
		btnClick(EditFleetPageObjects.SaveFleetButton_xpath);
		
	}
	
	
@Test(priority=25)
public void	editStoppedCampaign() throws Throwable{
		driver.get(CampaignsScreenURL);
		List<WebElement> CampaignList = driver.findElements(By.xpath("//table[@role='grid'] //tr[@role='row']"));
		for (int i = 0; i < CampaignList.size(); i++) {
			String Campaignname = CampaignList.get(i).getText();
			System.out.println(Campaignname);
			if (Campaignname.contains("Stopped")) {
			List<WebElement> StoppedList = driver.findElements(By.xpath("//*[@class='campaign-name']"));
				List<WebElement> SavedL = StoppedList;
				SavedL.get(i).click();
				break;
			} else {
				System.out.println("Not found");
			}
			
				}
		pause(5000);
		boolean stoppedButtonEnabled=driver.findElement(By.xpath("//*[@class='start-stop-button-content']")).isEnabled();
		System.out.println(stoppedButtonEnabled);
		if(stoppedButtonEnabled==true) {
			scrollPageBy(0,1000);
			cropImage(EditFleetPageObjects.StoppedButton_xpath,"stoppedbuttonimg");
		}
		
		}
	@Test(priority=26)
	public void editFleetAndCancelEdit() throws Throwable{
		
		driver.get(FleetManagementScreenURL);
		
		click(LocType.xpath,EditFleetPageObjects.Editfleetlink_xpath);
		//Use Assertflase  to verify whether Campname changed
		clear(LocType.xpath,EditFleetPageObjects.fleetCampaignname_xpath);
		enterText(EditFleetPageObjects.fleetCampaignname_xpath,excel(file, 0, 1, 0) +""+getTimeStamp());
		clear(LocType.xpath,EditFleetPageObjects.fleetCampaignContext_xpath);
		enterText(EditFleetPageObjects.fleetCampaignContext_xpath, excel(file, 0, 1, 2));
		clear(LocType.xpath,EditFleetPageObjects.FleetNumberofactiveVINS_xpath);
		enterText(EditFleetPageObjects.FleetNumberofactiveVINS_xpath, excel(file, 0, 1, 1));
		btnClick(EditFleetPageObjects.CancelButton_xpath);
	}
	@Test(priority=27)
	public void editFleetAddingMultipleVINS() throws Throwable {
		driver.get(FleetManagementScreenURL);
		click(LocType.xpath,EditFleetPageObjects.EditFleet_xpath);
		clear(LocType.xpath,EditFleetPageObjects.fleetCampaignname_xpath);
		enterText(EditFleetPageObjects.fleetCampaignname_xpath,excel(file, 0, 1, 0) +""+getTimeStamp());
	    clear(LocType.xpath,EditFleetPageObjects.fleetCampaignContext_xpath);
		enterText(EditFleetPageObjects.fleetCampaignContext_xpath, excel(file, 0, 1, 2));
		clear(LocType.xpath,EditFleetPageObjects.FleetNumberofactiveVINS_xpath);
		enterText(EditFleetPageObjects.FleetNumberofactiveVINS_xpath, excel(file1, 1, 1, 0));
		btnClick(EditFleetPageObjects.AddVINSButton_xpath);
		pause(5000);
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\VINfile.exe");
		btnClick(EditFleetPageObjects.AddVINSButton_xpath);
		pause(5000);
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\ValidVin.exe");
		btnClick(EditFleetPageObjects.AddVINSButton_xpath);
		pause(5000);
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\ValidVin2.exe");
		scrollPageBy(0,1000);
		cropImage(EditFleetPageObjects.AlreadyusedwarningMsg_xpath,"RemoveFleetWarningMessage");
		pause(5000);
		btnClick(EditFleetPageObjects.SaveFleetButton_xpath);
		System.out.println(getText(LocType.xpath,EditFleetPageObjects.NumOfOngoingAssociations_xpath));

		
	}
	
}











