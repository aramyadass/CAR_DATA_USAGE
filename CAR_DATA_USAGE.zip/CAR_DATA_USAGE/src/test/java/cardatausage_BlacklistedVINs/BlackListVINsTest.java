package cardatausage_BlacklistedVINs;

import java.io.IOException;

import org.testng.annotations.Test;

import CarDataPages.BlacklistedVINsPageObjects;
import cardatausage_Base.BaseClass;
import cardatausage_Base.LocType;

public class BlackListVINsTest extends BaseClass{
static String BlacklistedVINsURL= "https://cc-system-web-staging.apps.stage-eu.kamereon.io/blacklist";
	
	@Test
	
	public void ImportVINsToBlackListWithInvalidFileFormat() throws IOException{
		driver.get(BlacklistedVINsURL);
		btnClick(BlacklistedVINsPageObjects.ImportVINsbutton_xpath);
		
	}
}
