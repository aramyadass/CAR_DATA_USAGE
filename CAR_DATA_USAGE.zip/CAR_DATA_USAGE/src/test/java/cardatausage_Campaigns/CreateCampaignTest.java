
package cardatausage_Campaigns;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Sleeper;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import CarDataPages.CreateCampaignPages;
import CarDataPages.DuplicateCampaignPageObjects;
import CarDataPages.EditFleetPageObjects;
import cardatausage_Base.BaseClass;
import cardatausage_Base.LocType;

public class CreateCampaignTest extends BaseClass {
	static String file = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInput.xlsx";
	static String file1 = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInputfleet.xlsx";

public static void CreateCamp(String configfile, String css, int yHei) {
		try {
			Thread.sleep(15000);
			// static String config
			btnClick(CreateCampaignPages.create);
			enterText(CreateCampaignPages.campname, excel(file, 0, 1, 0) + "" + getTimeStamp());
			System.out.println();
			enterTextByClass(CreateCampaignPages.planduration, excel(file, 0, 1, 1));
			enterText(CreateCampaignPages.context, excel(file, 0, 1, 2));
			/*
			 * WebDriverWait wait = new WebDriverWait(driver,5500);
			 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
			 * "//*[@id='campaignContext']")));
			 */
			pause(5000);
			btnClick(CreateCampaignPages.ConfigurationFilesDropDownButton_xpath);
			// driver.manage().timeouts().implicitlyWait(2000,TimeUnit.SECONDS);
			pause(4000);

			btnClick("//span[contains(text(),'" + configfile + "')]");
			// btnClick(CreateCampaignPages.config1.replace("GEE", configfile));
			btnClick_Mat(CreateCampaignPages.save);
			// driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	} 

	@Test(priority = 2)
	public static void createCampGEE() throws IOException {
		// CreateCamp(excel(file,0,1,3));
		String congFile = excel(file, 0, 1, 3);
		try {
			Thread.sleep(15000);
			// static String config
			btnClick(CreateCampaignPages.create);
			enterText(CreateCampaignPages.campname, excel(file, 0, 1, 0) + "" + getTimeStamp());
			System.out.println();
			enterTextByClass(CreateCampaignPages.planduration, excel(file, 0, 1, 1));
			enterText(CreateCampaignPages.context, excel(file, 0, 1, 2));
			pause(5000);
			btnClick(CreateCampaignPages.ConfigurationFilesDropDownButton_xpath);
			pause(4000);
			btnClick("//span[contains(text(), '" + congFile + "')]");

			btnClick_Mat(CreateCampaignPages.save);
			pause(2000);

			String fleetname = excel(file, 0, 1, 3);

			// CreateFleet(fleetname1, activenumber, fleetcontext);
		}
		// driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
		catch (Exception e) {
			e.printStackTrace();
		}

	}

	
	  @Test(priority = 3) 
	  public static void createCampECLARAIGE() throws IOException { 
		  driver.get("https://cc-system-web-staging.apps.stage-eu.kamereon.io/campaigns");
	// static String config
	 String congFile = excel(file, 0, 2, 3); 
	 try { 
		 Thread.sleep(15000); 
	  btnClick(CreateCampaignPages.create);
	  enterText(CreateCampaignPages.campname, excel(file, 0, 1, 0) + "" +
	  getTimeStamp()); System.out.println();
	  enterTextByClass(CreateCampaignPages.planduration, excel(file, 0, 1, 1));
	 enterText(CreateCampaignPages.context, excel(file, 0, 1, 2)); 
	 pause(5000);
	  btnClick(CreateCampaignPages.ConfigurationFilesDropDownButton_xpath); 
	  pause(4000);
	  btnClick("//span[contains(text(), '" + congFile + "')]");
	 
	  btnClick_Mat(CreateCampaignPages.save); 
	  pause(2000); } 
	 // driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
	 catch(Exception e) { 
		 e.printStackTrace();
		 }
	  
	  }
	  
	  @Test(priority = 4) 
	  public static void createCampstartstop() throws IOException {
		  
		  driver.get("https://cc-system-web-staging.apps.stage-eu.kamereon.io/campaigns");
	 
	 String congFile = excel(file, 0, 3, 3);
	 try { 
		 Thread.sleep(15000); // static String config
	  btnClick(CreateCampaignPages.create);
	 enterText(CreateCampaignPages.campname, excel(file, 0, 1, 0) + "" +getTimeStamp()); 
	 System.out.println();
	 enterTextByClass(CreateCampaignPages.planduration, excel(file, 0, 1, 1));
	 enterText(CreateCampaignPages.context, excel(file, 0, 1, 2)); 
	 pause(5000);
	  btnClick(CreateCampaignPages.ConfigurationFilesDropDownButton_xpath);
	  pause(2000);
	  scrollINElement("#cdk-overlay-0 > div > div", 250); 
	  pause(4000);
	 btnClick("//span[contains(text(), '" + congFile + "')]");
	 
	  btnClick_Mat(CreateCampaignPages.save);
	  pause(2000);
	  } 
	 //driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS); 
	 catch
	  (Exception e) { e.printStackTrace();
	  } 
	 }
	  
	  @Test(priority = 5) 
	  public static void createCampDeem() throws IOException {
	  driver.get("https://cc-system-web-staging.apps.stage-eu.kamereon.io/campaigns");
	  
	  String congFile = excel(file, 0, 4, 3); 
	  try { 
	  Thread.sleep(15000); 
	// static String config
	   btnClick(CreateCampaignPages.create);
	  enterText(CreateCampaignPages.campname, excel(file, 0, 1, 0) + "" + getTimeStamp()); 
	  System.out.println();
	  enterTextByClass(CreateCampaignPages.planduration, excel(file, 0, 1, 1));
	  enterText(CreateCampaignPages.context, excel(file, 0, 1, 2)); 
	  pause(5000);
	  btnClick(CreateCampaignPages.config); 
	  pause(2000);
	  scrollINElement("#cdk-overlay-0 > div > div", 250); 
	  pause(4000);
	  btnClick("//span[contains(text(), '" + congFile + "')]");
	  
	  btnClick_Mat(CreateCampaignPages.save); 
	  pause(2000); 
	  } 
	  //driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS); 
	  catch(Exception e) { 
		  e.printStackTrace(); } 
	  }
	 
	 @Test(priority = 6)
	  
	  public static void createCampcassiope() throws IOException {
		 driver.get("https://cc-system-web-staging.apps.stage-eu.kamereon.io/campaigns");
	  
	  String congFile = excel(file, 0, 5, 3);
	  try { Thread.sleep(15000); // static String config
	   btnClick(CreateCampaignPages.create);
	  enterText(CreateCampaignPages.campname, excel(file, 0, 1, 0) + "" + getTimeStamp()); 
	  System.out.println();
	 enterTextByClass(CreateCampaignPages.planduration, excel(file, 0, 1, 1));
	  enterText(CreateCampaignPages.context, excel(file, 0, 1, 2)); pause(5000);
	  btnClick(CreateCampaignPages.ConfigurationFilesDropDownButton_xpath); pause(2000);
	 scrollINElement("#cdk-overlay-0 > div > div", 250); pause(4000);
	  btnClick("//span[contains(text(), '" + congFile + "')]");
	  
	  btnClick_Mat(CreateCampaignPages.save); pause(2000); } 
	  //driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS); 
	  
	 
	  catch(Exception e) { 
		  e.printStackTrace();
} 
	  }
	  @Test(priority = 7) 
	  public static void createCampenergy() throws IOException
	  { 
		  driver.get("https://cc-system-web-staging.apps.stage-eu.kamereon.io/campaigns");
	  
	  String congFile = excel(file, 0, 6, 3); try { Thread.sleep(15000); 
	  // static String config 
	  btnClick(CreateCampaignPages.create);
	  enterText(CreateCampaignPages.campname, excel(file, 0, 1, 0) + "" +
	  getTimeStamp()); System.out.println();
	  enterTextByClass(CreateCampaignPages.planduration, excel(file, 0, 1, 1));
	  enterText(CreateCampaignPages.context, excel(file, 0, 1, 2)); pause(5000);
	  btnClick(CreateCampaignPages.ConfigurationFilesDropDownButton_xpath); pause(2000);
	  scrollINElement("#cdk-overlay-0 > div > div", 250); pause(4000);
	  btnClick("//span[contains(text(), '" + congFile + "')]"); pause(2000);
	  btnClick_Mat(CreateCampaignPages.save);
	 
	  } // driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS); 
	  catch
	 (Exception e) { e.printStackTrace();
	 } 
	  }
	 

	@Test(priority = 8,dependsOnMethods="createCampGEE",description="Creating Fleets in the Campaigns Functionality with xlxs file")
	//Assignee- Ramya -Z030183(06/10/2020)
	//Creating Fleets in the Campaigns Functionality with different set of data
	
	public void createFleet_InvalidFile() throws IOException {
		pause(5000);
		//createCampGEE();
		pause(3000);
        enterText(CreateCampaignPages.fleetname, excel(file1, 0, 1, 0)+ "" + getTimeStamp());
		pause(3000);
		enterTextByClass(CreateCampaignPages.activenumber, excel(file1, 0, 1, 1));
		pause(3000);
        enterText(CreateCampaignPages.fleetcontext, excel(file1, 0, 1, 2));
        btnClick(CreateCampaignPages.FleetImportbutton_xpath);
		pause(3000);
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\InvalidVINFile.exe");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		pause(2000);
		btnClick_Mat(CreateCampaignPages.fleetsave);
		scrollPageBy(0,1000);
		cropImage(CreateCampaignPages.blacklistfleetWarningMessage,"InvalidFileWarningMSG.png");
	    btnClick_Mat(CreateCampaignPages.fleetdismiss);
		btnClick_Mat(CreateCampaignPages.addnewfleet);

		

	}

	@Test(priority = 9)
	public void createFleet_AlreadyUsedVIN() throws IOException {

		implicitWait();
		clear(LocType.xpath,CreateCampaignPages.fleetname);
		enterText(CreateCampaignPages.fleetname, excel(file1, 0, 1, 0)+ "" + getTimeStamp());
		
		enterTextByClass(CreateCampaignPages.activenumber, excel(file1, 0, 1, 1));
		enterText(CreateCampaignPages.fleetcontext, excel(file1, 0, 1, 2));
		pause(3000);
		btnClick(CreateCampaignPages.FleetImportbutton_xpath);
		pause(3000);
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\ValidVin.exe");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		pause(2000);
		btnClick_Mat(CreateCampaignPages.fleetsave);
		pause(3000);
		scrollPageBy(0,1000);
		cropImage(CreateCampaignPages.blacklistfleetWarningMessage,"AlreadyusedVIN.png");
		
		btnClick_Mat(CreateCampaignPages.fleetdismiss);
		btnClick_Mat(CreateCampaignPages.addnewfleet);
		
		


	}

	@Test(priority = 10)
	public void createFleet_BlackListedVIN() throws IOException {
		
		enterText(CreateCampaignPages.fleetname, excel(file1, 0, 1, 0)+ "" + getTimeStamp());
		
		enterTextByClass(CreateCampaignPages.activenumber, excel(file1, 0, 1, 1));
		enterText(CreateCampaignPages.fleetcontext, excel(file1, 0, 1, 2));
		btnClick(DuplicateCampaignPageObjects.UploadFleetSheetButton_xpath);
		pause(3000);
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\BlacklistedVIN.exe");
		pause(5000);
		scrollPageBy(0,1000);
		cropImage(CreateCampaignPages.BlacklistVINWarningMSG_xpath,"FleetBlackListWarningMSG");
		//btnClick(DuplicateCampaignPageObjects.DoneButton_xpath);
		//pause(4000);
	//	click(LocType.xpath,DuplicateCampaignPageObjects.CampaignDetailsLink_xpath);
	
		//driver.findElement(By.id("fleet-import")).sendKeys("C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\VINTESTCDUMOCK001.csv");
		//JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		//pause(2000);
	//	btnClick_Mat(CreateCampaignPages.fleetsave);
		//pause(3000);
		//WebElement blacklistfleetWarningMessage = driver.findElement(By.xpath("(//*[@class='add-vins-to-fleet'])[2]"));
		//File src = blacklistfleetWarningMessage.getScreenshotAs(OutputType.FILE);
		//FileUtils.copyFile(src, new File("FleetBlackListWarningMSG.png"));

	}

	@Test(priority = 11)
	public void createFleet_InvalidData() throws Throwable {
		pause(3000);
		enterText(CreateCampaignPages.fleetname, excel(file1, 1, 1, 0));
		
		enterTextByClass(CreateCampaignPages.activenumber, excel(file1, 1, 1, 1));
		pause(3000);
		enterText(CreateCampaignPages.fleetcontext, excel(file1, 1, 1, 2));
		pause(3000);
		driver.findElement(By.id("fleet-import"))
				.sendKeys("C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\VINTESTCDUMOCK001.csv");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		pause(2000);
		btnClick_Mat(CreateCampaignPages.fleetsave);

	}

	@Test(priority = 12)
	public void createFleet_ValidVIN() throws Throwable {
		try{
			implicitWait();
		enterText(CreateCampaignPages.fleetname, excel(file1, 0, 1, 0)+ "" + getTimeStamp());
		enterTextByClass(CreateCampaignPages.activenumber, excel(file1, 0, 1, 1));
		enterText(CreateCampaignPages.fleetcontext, excel(file1, 0, 1, 2));
		driver.findElement(By.id("fleet-import"))
				.sendKeys("C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\VF1RJA00960487720.csv");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		btnClick_Mat(CreateCampaignPages.fleetsave);
		System.out.println(" Saved Fleet Successfully");
		click(LocType.xpath, CreateCampaignPages.donebutton_xpath);
		click(LocType.xpath, CreateCampaignPages.detailClick);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

}
