package cardatausage_Campaigns;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import CarDataPages.CreateCampaignPages;
import CarDataPages.DuplicateCampaignPageObjects;
import CarDataPages.EditFleetPageObjects;
import CarDataPages.EditSavedCampaignPageObjects;
import cardatausage_Base.BaseClass;
import cardatausage_Base.LocType;

public class DuplicateCreatedCampaignsTest extends BaseClass {
	static String file = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInput.xlsx";
	static String file1 = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInputfleet.xlsx";

	static String FleetManagementScreenURL="https://cc-system-web-staging.apps.stage-eu.kamereon.io/fleets";
	static String CampaignsScreenURL= "https://cc-system-web-staging.apps.stage-eu.kamereon.io/campaigns";
	SoftAssert s= new SoftAssert();
	
@Test (priority=13)
	public void duplicateCampaignWithNewConfigFile() throws IOException{
	driver.get(CampaignsScreenURL);
		implicitWait();
		List<WebElement> CampaignList = driver.findElements(By.xpath("//table[@role='grid'] //tr[@role='row']"));
		pause(4000);
		for (int i = 0; i < CampaignList.size(); i++) {
			String Campaignname = CampaignList.get(i).getText();
			System.out.println(Campaignname);
			if (Campaignname.contains("Launched")) {
				pause(5000);
				List<WebElement> LaunchedList = driver.findElements(By.xpath("//a[@class='campaign-name']"));
				List<WebElement> SavedL = LaunchedList;
				pause(5000);
				SavedL.get(i).click();
				break;
			} else {
				System.out.println("Not found");
			}
			}
		pause(5000);
		click(LocType.xpath,DuplicateCampaignPageObjects.Changeversionbutton_xpath);
		pause(3000);
		click(LocType.xpath,DuplicateCampaignPageObjects.NOCancelbutton_xpath);
		click(LocType.xpath,DuplicateCampaignPageObjects.Changeversionbutton_xpath);
		click(LocType.xpath,DuplicateCampaignPageObjects.YesContinuebutton_xpath);
		enterText(DuplicateCampaignPageObjects.CampaignContextTextBox_xpath,excel(file,0,1,2));
		
		btnClick(DuplicateCampaignPageObjects.ConfigurationFilesDropDownButton_xpath);
		pause(4000);
		List<WebElement> Configurationfiles = driver.findElements(By.xpath("//div[@class='cdk-overlay-pane']"));
		for(WebElement configlist:Configurationfiles) {
			System.out.println(configlist.getText());
			configlist.click();
		}
		btnClick(DuplicateCampaignPageObjects.SaveButton_xpath);
		pause(5000);
		btnClick(DuplicateCampaignPageObjects.DoneButton_xpath);
		pause(4000);
		click(LocType.xpath,DuplicateCampaignPageObjects.CampaignDetailsLink_xpath);
		pause(4000);
		driver.get(CampaignsScreenURL);
		btnClick(DuplicateCampaignPageObjects.DeleteButton_xpath);
		click(LocType.xpath,DuplicateCampaignPageObjects.ConfirmDeleteYesContinuebutton_xpath);
		
		}
	@Test(priority=14)
	public static void duplicateCampaignWithBlackListedVIN() throws IOException{
		implicitWait();
		List<WebElement> CampaignList = driver.findElements(By.xpath("//table[@role='grid'] //tr[@role='row']"));
		for (int i = 0; i < CampaignList.size(); i++) {
			String Campaignname = CampaignList.get(i).getText();
			System.out.println(Campaignname);
			if (Campaignname.contains("Launched")) {
				List<WebElement> LaunchedList = driver.findElements(By.xpath("//a[@class='campaign-name']"));
				List<WebElement> SavedL = LaunchedList;
				SavedL.get(i).click();
				break;
		
				
			} else {
				System.out.println("Not found");
			}
			}
		
		click(LocType.xpath,DuplicateCampaignPageObjects.Changeversionbutton_xpath);
		click(LocType.xpath,DuplicateCampaignPageObjects.YesContinuebutton_xpath);
		enterText(DuplicateCampaignPageObjects.CampaignContextTextBox_xpath,excel(file,0,1,2));
		pause(4000);
		btnClick(DuplicateCampaignPageObjects.ConfigurationFilesDropDownButton_xpath);
		pause(4000);
		List<WebElement> Configurationfiles = driver.findElements(By.xpath("//div[@class='cdk-overlay-pane']"));
		for(WebElement configlist:Configurationfiles) {
			System.out.println(configlist.getText());
			configlist.click();
		}
		btnClick(DuplicateCampaignPageObjects.SaveButton_xpath);
		pause(4000);
		btnClick(DuplicateCampaignPageObjects.UploadFleetSheetButton_xpath);
		Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\BlacklistedVIN.exe");
		pause(5000);
		scrollPageBy(0,1000);
		cropImage(DuplicateCampaignPageObjects.Duplicate_UploadBlackListedsheetWarningMSG_xpath,"DuplicateFleetSheetBlacklistedWarningMessage");
		btnClick(DuplicateCampaignPageObjects.DoneButton_xpath);
		pause(4000);
		click(LocType.xpath,DuplicateCampaignPageObjects.CampaignDetailsLink_xpath);
		pause(4000);
		driver.get(CampaignsScreenURL);
		btnClick(DuplicateCampaignPageObjects.DeleteButton_xpath);
		click(LocType.xpath,DuplicateCampaignPageObjects.ConfirmDeleteYesContinuebutton_xpath);
		}
		
	@Test(priority=15)
	public void duplicateCampaignswithMultilpleVINFleetSheet() throws Throwable{
		implicitWait();
		driver.get(CampaignsScreenURL);
		List<WebElement> CampaignList = driver.findElements(By.xpath("//table[@role='grid'] //tr[@role='row']"));
		for (int i = 0; i < CampaignList.size(); i++) {
			String Campaignname = CampaignList.get(i).getText();
			System.out.println(Campaignname);
			if (Campaignname.contains("Launched")) {
				List<WebElement> LaunchedList = driver.findElements(By.xpath("//a[@class='campaign-name']"));
				List<WebElement> SavedL = LaunchedList;
				SavedL.get(i).click();
				break;
			} else {
				System.out.println("Not found");
			}
			}
		
		click(LocType.xpath,DuplicateCampaignPageObjects.Changeversionbutton_xpath);
		click(LocType.xpath,DuplicateCampaignPageObjects.YesContinuebutton_xpath);
		enterText(DuplicateCampaignPageObjects.CampaignContextTextBox_xpath,excel(file,0,1,2));
		pause(4000);
		btnClick(DuplicateCampaignPageObjects.ConfigurationFilesDropDownButton_xpath);
		//driver.findElement(By.xpath("//mat-select[@id='campaignConfig']")).click();
		pause(4000);
		List<WebElement> Configurationfiles = driver.findElements(By.xpath("//div[@class='cdk-overlay-pane']"));
		
		for(WebElement configlist:Configurationfiles) {
		
			System.out.println(configlist.getText());
			configlist.click();
		}
		btnClick(DuplicateCampaignPageObjects.SaveButton_xpath);
		pause(5000);
		btnClick(DuplicateCampaignPageObjects.UploadFleetSheetButton_xpath);
		uploadFileAutoit("C:\\Users\\z030183\\eclipse-workspace\\CAR_DATA_USAGE\\VF1RJA00960487720.csv");
		//Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\BlacklistedVIN.exe");
		pause(5000);
		btnClick(DuplicateCampaignPageObjects.UploadFleetSheetButton_xpath);
		btnClick(DuplicateCampaignPageObjects.DoneButton_xpath);
		pause(4000);
		
		uploadFileAutoit("C:\\Users\\z030183\\eclipse-workspace\\CAR_DATA_USAGE\\VF1RJAGR001567872.csv");
		//uploadFileAutoit("C:\\Users\\z030183\\eclipse-workspace\\CAR_DATA_USAGE\\VF1SYMNJR06716442.csv");
		//Runtime.getRuntime().exec("C:\\Users\\z030183\\OneDrive - Alliance\\Documents\\ValidVin.exe");
		pause(4000);
		scrollPageBy(0,1000);
		cropImage(DuplicateCampaignPageObjects.Duplicate_UploadBlackListedsheetWarningMSG_xpath,"DuplicateFleetSheetBlacklistedWarningMessage");
		click(LocType.xpath,DuplicateCampaignPageObjects.CampaignDetailsLink_xpath);
		pause(4000);
		driver.get(CampaignsScreenURL);
		btnClick(DuplicateCampaignPageObjects.DeleteButton_xpath);
		click(LocType.xpath,DuplicateCampaignPageObjects.ConfirmDeleteYesContinuebutton_xpath);
		
		}
		
		
		
	
}
