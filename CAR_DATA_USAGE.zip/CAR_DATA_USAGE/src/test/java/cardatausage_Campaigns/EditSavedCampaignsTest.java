package cardatausage_Campaigns;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;


import cardatausage_Campaigns.CreateCampaignTest;
import CarDataPages.CreateCampaignPages;
import CarDataPages.DuplicateCampaignPageObjects;
import CarDataPages.EditSavedCampaignPageObjects;
import cardatausage_Base.BaseClass;
import cardatausage_Base.LocType;
import edu.emory.mathcs.backport.java.util.Arrays;
import edu.emory.mathcs.backport.java.util.Collections;

public class EditSavedCampaignsTest extends BaseClass {

	static String file = "C:\\Users\\z030183\\Downloads\\CAR_DATA_USAGE\\CAR_DATA_USAGE\\AutomationInput.xlsx";
	static String CampaignScreenURL = "https://cc-system-web-staging.apps.stage-eu.kamereon.io";

	@Test(priority = 16)

	public void editCampaignName() throws IOException {
		implicitWait();
		List<WebElement> CampaignList = driver.findElements(By.xpath("//table[@role='grid'] //tr[@role='row']"));
		for (int i = 0; i < CampaignList.size(); i++) {
			String Campaignname = CampaignList.get(i).getText();
			System.out.println(Campaignname);
			if (Campaignname.contains("Saved")) {
			List<WebElement> SavedList = driver.findElements(By.xpath("//*[@class='campaign-name']"));
				List<WebElement> SavedL = SavedList;
				SavedL.get(i).click();
				break;
			} else {
				System.out.println("Not found");
			}
		}
		click(LocType.xpath, EditSavedCampaignPageObjects.campName_xpath);
	    btnClick(EditSavedCampaignPageObjects.editbutton_Xpath);
		clear(LocType.xpath,EditSavedCampaignPageObjects.CampaignName_Xpath);
		enterText(EditSavedCampaignPageObjects.CampaignName_Xpath,excel(file,0, 1, 0)+""+getTimeStamp());
		btnClick_Mat(EditSavedCampaignPageObjects.save);

	}

	@Test(priority = 17)

	public void editCampaignPlannedDuration() throws IOException {
		
		pause(5000);
		click(LocType.xpath,EditSavedCampaignPageObjects.CampaignEdit_xpath);
		clear(LocType.className,EditSavedCampaignPageObjects.planduration_className);
		enterTextByClass(EditSavedCampaignPageObjects.planduration_className,excel(file,0, 1, 1));
		//driver.findElement(By.className("campaign-duration-input")).sendKeys("1");
		btnClick_Mat(EditSavedCampaignPageObjects.save);
	}

	@Test(priority = 18)
	public void editCampaignContext() throws Throwable {
		implicitWait();
		click(LocType.xpath,EditSavedCampaignPageObjects.CampaignEdit_xpath);
		clear(LocType.xpath,EditSavedCampaignPageObjects.CampaignContext_Xpath);
		enterText(EditSavedCampaignPageObjects.CampaignContext_Xpath,excel(file,0, 1, 2));
		//driver.findElement(By.xpath("//input[@id='campaignContext']")).sendKeys("Contextt");
		btnClick_Mat(EditSavedCampaignPageObjects.save);

	}

	@Test(priority = 19)
	public void editCampaignConfigurationFiles() throws Throwable {
		implicitWait();
		click(LocType.xpath,EditSavedCampaignPageObjects.CampaignEdit_xpath);
		btnClick(EditSavedCampaignPageObjects.ConfigurationFilesDropDownButton_xpath);
		List<WebElement> configurationFiles = driver.findElements(By.xpath("//div[@class='cdk-overlay-pane']"));
		for (int i = 0; i <configurationFiles.size(); i++) {
			String ConfigfilesNames = configurationFiles.get(i).getText();
			System.out.println(ConfigfilesNames);
			pause(3000);
			configurationFiles.get(i).click();
			btnClick_Mat(EditSavedCampaignPageObjects.save);
		}
		if (configurationFiles.contains(element)) {
			scrollPageBy(125, 425);
			cropImage(EditSavedCampaignPageObjects.WariningMSG_xpath,"EditCampaignConfigfilesWarningMessage");
			
		} else {
			System.out.println("Sucessfully Edited ");
		}
		
     btnClick(EditSavedCampaignPageObjects.donebutton_xpath);
     
   //  String expected_details="Campaign Details";
  //   String actual_Details= getText(LocType.xpath,EditSavedCampaignPageObjects.DetailsLink_xpath);
  //  Assert.assertEquals("actual_Details", expected_details);
	}
	
}
