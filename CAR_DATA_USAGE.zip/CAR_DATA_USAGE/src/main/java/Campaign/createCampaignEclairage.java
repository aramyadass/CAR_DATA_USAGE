package Campaign;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import CarDataPages.CreateCampaignPages;
import cardatausage_Base.BaseClass;

public class createCampaignEclairage extends BaseClass{
	
	 @Test(priority=2)  
	  public void CreateCamp2() throws IOException, InterruptedException{
		 Thread.sleep(15000);
		
		  btnClick(CreateCampaignPages.create); 
		  enterText(CreateCampaignPages.campname, "campname"+ getTimeStamp());
		  enterTextByClass(CreateCampaignPages.planduration,"11");	
		  enterText(CreateCampaignPages.context, "CONTEXT");
		  /*WebDriverWait wait = new WebDriverWait(driver,5500);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='campaignContext']")));*/
		  pause(5000);
		  btnClick(CreateCampaignPages.config);
		  driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
		  btnClick(CreateCampaignPages.configECL);
		  btnClick_Mat(CreateCampaignPages.save);
		  driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
		  //fleet
		  btnClick_Mat(CreateCampaignPages.fleetdismiss);
		  pause(5000);
		  btnClick_Mat(CreateCampaignPages.addnewfleet);
		  enterText(CreateCampaignPages.fleetname,"FleetName2");
		  enterTextByClass(CreateCampaignPages.activenumber,"11");
		  enterText(CreateCampaignPages.fleetcontext,"Fleetcontext2");
		  //btnClick(CreateCampaignPages.fleetimport);
		   driver.findElement(By.id("fleet-import")).sendKeys("C:\\Users\\Public\\AIC\\CDU\\STAG-VIN\\VF1RJAGR001567872- inputfile.csv");
		   JavascriptExecutor js = (JavascriptExecutor) driver;  
		   js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		   pause(2000);
		   //driver.findElement(By.className("save-fleet mat-button mat-button-base mat-primar"))
		   btnClick_Mat(CreateCampaignPages.fleetsave);
		   //System.out.println(testError);
		  //Done 
		  btnClick(CreateCampaignPages.donebutton_xpath);
		  btnClick_Mat(CreateCampaignPages.detailClick);
		  btnClick_Mat(CreateCampaignPages.detailClickhome);
		  //pause(2000);
		  //driver.navigate().back();
		  //Home detail navigate
		  //btnClick_Mat(CreateCampaignPages.detailClickhome);
		  
	  }

}
