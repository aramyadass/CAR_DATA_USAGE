package CarDataPages;

public class CreateCampaignPages {
	
	
	public static final String create = "//*[@id='create-campaign']";
	public static final String campname = "//*[@id='campaignName']";
	public static final String planduration = "campaign-duration-input";
	public static final String context = "//*[@id='campaignContext']";
	public static final String config = "//div[contains(text(),'mat-select-arrow']";
	public static final String ConfigurationFilesDropDownButton_xpath = "//mat-select[@aria-label='Select a config file']";
	public static final String config1 ="//span[contains(text(),'GEE')]";
	public static final String configECL ="//span[contains(text(),'ECLAIRAGE')]";
	public static final String save = "save-campaign-button";
	
	//create with fleet
	public static final String fleetname ="//input[@placeholder='Fleet name']"; 
	public static final String activenumber = "fleet-active-vins";
	public static final String fleetcontext ="//*[@id='fleet-context']";
	public static final String fleetimport ="//*[@id='fleet-import-button']";
	public static final String fleetsave ="save-fleet";
	public static final String fleetdismiss ="dismiss";
	public static final String addnewfleet = "add-fleet-button";
	public static final String uploadfleetImportbutton_Xpath="//input[@id='fleet-import']";
	public static final String saveerrormsg_invalidfleet_Xpath= "//p[contains(text(),'An error occurred while saving the fleet..')]";
	
	public static final String donebutton_xpath = "(//*[@tabindex='-1'])[2]";
	public static final String detailClick = "//a[contains(text(),'Campaign Details')]";
	public static final String detailClickhome ="//a[contains(text(),'campname20200925095805')]";
	public static final String blacklistfleetWarningMessage="//section[@class='content']";
	public static final String FleetImportbutton_xpath="//button[@id='fleet-import-button']";
	public static final String BlacklistVINWarningMSG_xpath="//section[@class='content']";
	public static final String conifclick = "/html/body/app-root/app-homepage/app-page-with-menu/app-page/mat-toolbar/mat-toolbar-row[2]/app-menu/nav/div[2]/div/div/a[5]";
    public static final String nameconfig = "//*[@id='name']";
    public static final String nameuid = "//*[@id='uid']";
    public static final String saveButton_Xpath="//app-page-header/section[1]/button[1]";
    public static final String confirmation ="//section[@class='content']";
}
