package CarDataPages;

public class ConfigFilesPageObjects {

	public static final String ConfigFilesTab_Xpath = "/html/body/app-root/app-homepage/app-page-with-menu/app-page/mat-toolbar/mat-toolbar-row[2]/app-menu/nav/div[2]/div/div/a[5]";
	public static final String enterConfigFileName_Xpath = "//input[@id='name']";
	public static final String enterUID_Xpath = "//input[@id='uid']";
	public static final String saveButton_Xpath="//span[contains(text(),'Save')]";
	
	
}
