package CarDataPages;

public class EditFleetPageObjects {

	
	public static final String EditFleet_xpath="(//a[@class='fleet-action edit-fleet'])[1]";
	public static final String fleetCampaignname_xpath="//input[@id='name']";
	public static final String fleetCampaignContext_xpath="//*[@id='context']";
	public static final String fleetNamelink_xpath= "(//a[@class='fleet-name'])[1]";
	public static final String fleetNameinpageheader_css="h2[class*='page-header--title']";
	public static final String FleetNumberofactiveVINS_xpath= "//*[@id='minActivatedVins']";
	public static final String AddVINSButton_xpath="//*[@id='add-vin-to-fleet-button']";
	public static final String SaveFleetButton_xpath= "//span[contains(text(),'Save')]";
	public static final String EditfleetText_xpath="//input[@id='name']";
	public static final String fleetNameinPageheader2_xpath= "//h2[@class='page-header--title']";
	public static final String AlreadyusedwarningMsg_xpath= "//section[@class='content']";
	public static final String Blacklistedwarningmsg_xpath= "//div[@class='fleet-warnings']";
	public static final String EditFleetaftersavebutton_xpath= "//span[contains(text(),'edit')]";
	public static final String StoppedButton_xpath = "//*[@class='start-stop-button-content']";
	public static final String messageafteraddingvlidvin= "//section[@class='content']";
	public static final String SyncAssociationbutton_xpath="(//section[@class='content'])[1]";
	public static final String TotalNoofAssociatedVINS_xpath ="(//div[@class='vin-category'])[1]";
	public static final String CancelButton_xpath ="//*[@id='cancelButton']";
	public static final String Editfleetlink_xpath= "//a[@href='/fleets/147/edit']";
	public static final String RemoveVINSButton_xpath="//*[@id='remove-vin-from-fleet-button']";
	public static final String NumOfOngoingAssociations_xpath= "(//span[@class='vin-category--number-of-vin'])[2]";

	
	
	
	
}
