package CarDataPages;

public class BlacklistedVINsPageObjects {
	public static final String ImportVINsbutton_xpath= "//mat-icon[contains(text(),'file_upload')]";
	
}
