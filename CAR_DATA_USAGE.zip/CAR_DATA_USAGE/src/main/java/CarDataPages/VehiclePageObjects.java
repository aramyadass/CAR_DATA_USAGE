package CarDataPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cardatausage_Base.LocType;

public class VehiclePageObjects {

	public static final String vehicleTab_Xpath = "/html/body/app-root/app-homepage/app-page-with-menu/app-page/mat-toolbar/mat-toolbar-row[2]/app-menu/nav/div[2]/div/div/a[3]";
	public static final String searchAVin_Xpath = "//input[@id='mat-input-0']";
	public static final String selectAConfigFile_Xpath = "//div[@class='mat-select-arrow-wrapper']";
	public static final String search_Xpath = "/html/body/app-root/app-vehicle/app-page-with-menu/app-page/section/section/div/mat-card/button";
			//"//*[@class='vehicle-dashboard--search-input-button mat-raised-button mat-button-base mat-primary']";

	// Select a config file Drop Down
	public static final String SelectAConfigFile_Xpath = "//mat-select[@id='configfile']/div/div[1]/span";
	public static final String Qwerty_Xpath	=	"//span[@class='mat-option-text'][contains(text(),'QWERTY')]";
	public static final String GEE_Xpath = "//span[contains(text(),'GEE')]";
	public static final String ECLAIRAGE_Xpath = "//span[contains(text(),'ECLAIRAGE')]";
	public static final String DEAM_Xpath = "//span[contains(text(),'DEAM')]";
	public static final String CASSIOPE_Xpath = "//span[contains(text(),'CASSIOPE')]";
	public static final String ENERGYMANAGEMENTSOP2_Xpath = "//*[@id='mat-option-19']/span";
	public static final String ACTIONSbutton_Xpath= "//span[contains(text(),'Actions')]";
	public static final String BlackListedVINResultText_Xpath= "//div[contains(text(),'This vehicle is blacklisted')]";
	public static final String BlackListedVINHeaderText_Xpath ="//*[@class='page-header--title']";
	public static final String AssociationStatus_xpath ="//tbody/tr[1]/td[4]";
	public static final String LaunchedButton_xpath ="//span[contains(text(),'Launched')]";
	public static final String SavedButton_xpath ="//span[contains(text(),'Saved')]";
	public static final String StoppedButton_xpath ="//span[contains(text(),'Stopped')]";
	public static final String CampaignsStatusbuttonsColor_xpath= "//div[@class='vehicle-dashboard-result--header']";
	public static final String CampaignNameLink_xpath="(//a[@class='vehicle-dashboard-table--link'])[1]";
	public static final String CampaignTitle_xpath= "//h2[@class='page-header--title']";
	public static final String FleetNameLink_xpath="//a[@class='fleet-name']";
	public static final String FleetTitle_xpath= "//h2[@class='page-header--title']";
	public static final String TotalofAssociatedVINs="(//span[@class=\"vin-category--number-of-vin\"])[1]";
	public static final String VINinsearchresult_xpath ="(//div[@class='vehicle-dashboard-result--header-text'])[1]";
	public static final String VehicleUsedinCampaign_xpath ="(//div[@class='vehicle-dashboard-result--header-text'])[2]";
	public static final String VinAssociatedconfigfile_xpath= "(//td[@role='gridcell'])[3]";
	public static final String RedWarningBox_xpath ="//div[@class='blacklisted-vin--card-content']";
	public static final String CampaignNameTitle_xpath ="(//div[@class='vehicle-dashboard-table--header-text'])[1]";
	public static final String FleetNameTitle_xpath ="(//div[@class='vehicle-dashboard-table--header-text'])[2]";
	public static final String ConfigFileTitlexpath ="(//div[@class='vehicle-dashboard-table--header-text'])[3]";
	public static final String  VINAssociationTitle_xpath= "(//div[@class='vehicle-dashboard-table--header-text'])[4]";
	public static final String  VINActivationTitle_xpath="(//div[@class='vehicle-dashboard-table--header-text'])[5]";
	
}
