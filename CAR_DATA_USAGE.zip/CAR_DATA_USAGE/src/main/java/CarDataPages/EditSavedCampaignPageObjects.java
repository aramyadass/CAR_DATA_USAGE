package CarDataPages;

public class EditSavedCampaignPageObjects {

	public static final String campName_xpath= "//*[@class='campaign-name']";
	public static final String editbutton_Xpath="//button[@id='editCampaign']";
	public static final String CampaignName_Xpath="//input[@id='campaignName']";
	public static final String CampaignEdit_xpath="//mat-step-header[@id='cdk-step-label-0-0']";
	public static final String CampaignContext_Xpath="//input[@id='campaignContext']";
	//public static final String CampaignDuration_className="campaign-duration-input";
	public static final String donebutton_xpath="//*[contains(text(),'Done')]";
	public static final String DetailsLink_xpath= "(//div[@class='mat-step-label.mat-step-label-active'])[2]";
	public static final String SaveFleetButton_xpath= "(//div[@class='mat-button-ripple mat-ripple'])[3]";
	 
	
	public static final String config = "//div[@class='mat-select-arrow']";
	public static final String ConfigurationFilesDropDownButton_xpath = "//mat-select[@aria-label='Select a config file']";
	public static final String config1 ="//span[contains(text(),'GEE')]";
	public static final String configECL ="//span[contains(text(),'ECLAIRAGE')]";
	public static final String planduration_className= "campaign-duration-input";
	public static final String save = "save-campaign-button";
	public static final String WariningMSG_xpath ="(//section[@class='content'])[1]";
	
	
	
}
