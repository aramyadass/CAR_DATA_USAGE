package CarDataPages;

public class DuplicateCampaignPageObjects {
	
	
	public static final String Changeversionbutton_xpath ="//*[contains(text(),'CHANGE VERSION')]";
			
	public static final String CampaignNameinTitle_Xpath= "//*[@class='page-header--title']";
	public static final String YesContinuebutton_xpath= "//*[contains(text(),'YES, CONTINUE')]";
	public static final String CampaignContextTextBox_xpath= "//*[@id='campaignContext']";
	public static final String ConfigurationFilesDropDownArrow_xpath = "//div[contains(text(),'mat-select-arrow']";
	public static final String ConfigurationFilesDropDownButton_xpath = "//mat-select[@id='campaignConfig']";
	public static final String SaveButton_xpath= "//span[contains(text(),'Save')]";
	public static final String DuplicatedCampaignNameTextbox_xpath= "//*[@id='campaignName']";
	public static final String DoneButton_xpath= "//*[contains(text(),'Done')]";
	public static final String CampaignDetailsLink_xpath = "//a[contains(text(),'Campaign Details')]";
	public static final String DeleteButton_xpath = "(//mat-icon[@class='mat-icon notranslate material-icons mat-icon-no-color'])[6]";
	public static final String ConfirmDeleteYesContinuebutton_xpath ="//span[contains(text(),'YES, CONTINUE')]";
	public static final String UploadFleetSheetButton_xpath="//button[@id='fleet-import-button']";
	public static final String Duplicate_UploadBlackListedsheetWarningMSG_xpath ="(//div[@class='fleet-warnings'])[2]";
	public static final String NOCancelbutton_xpath= "//*[contains(text(),'NO, CANCEL')]";
	public static final String NewCampaignConfigfileDropDown_xpath ="//*[@role='listbox']";
	public static final String Configfilelistbox_xpath= "//mat-select[@id='campaignConfig']";
	
}
