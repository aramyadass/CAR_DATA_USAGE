
  package cardatausage_Base;
  
  import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import CarDataPages.CreateCampaignPages;
  
  
  public class CreateCampaignTest extends BaseClass{
 @Test(priority=1)
 public void CreateCampaign() {
	 CreateCampaignTest obbj = new CreateCampaignTest();
	 obbj.CreateCamp("CAMPNAME", "1", "context", "ECLAIRAGE");
 }

   public void CreateCamp(String campname,String planduration,String context,String config1){
	 try{
	 Thread.sleep(15000);
	
	  btnClick(CreateCampaignPages.create); 
	  enterText(CreateCampaignPages.campname, campname);
	  enterTextByClass(CreateCampaignPages.planduration,planduration);	
	  enterText(CreateCampaignPages.context, context);
	  /*WebDriverWait wait = new WebDriverWait(driver,5500);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='campaignContext']")));*/
	  pause(5000);
	  btnClick(CreateCampaignPages.config);
	  driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
	  btnClick(CreateCampaignPages.config1.replace("GEE", config1));
	  btnClick_Mat(CreateCampaignPages.save);
	  driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
	 }  
	 catch(Exception e) {
		 e.printStackTrace();
	 }
  }
	  //fleet
	  public static void CreateFleet(String fleetname,String activenumber,String fleetcontext) {
		  try{
				 Thread.sleep(15000);
	  btnClick_Mat(CreateCampaignPages.fleetdismiss);
	  pause(5000);
	  btnClick_Mat(CreateCampaignPages.addnewfleet);
	  enterText(CreateCampaignPages.fleetname,fleetname);
	  enterTextByClass(CreateCampaignPages.activenumber,activenumber);
	  enterText(CreateCampaignPages.fleetcontext,fleetcontext);
	  //btnClick(CreateCampaignPages.fleetimport);
	   driver.findElement(By.id("fleet-import")).sendKeys("C:\\Users\\Public\\AIC\\CDU\\STAG-VIN\\VF1RJAGR001567872- inputfile.csv");
	   JavascriptExecutor js = (JavascriptExecutor) driver;  
	   js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	   pause(2000);
	   //driver.findElement(By.className("save-fleet mat-button mat-button-base mat-primar"))
	   btnClick_Mat(CreateCampaignPages.fleetsave);
		  }
		  catch(Exception e) {
				 e.printStackTrace();
			 }
	  
		  
		
	   //System.out.println(testError);
	  //Done 
	 // btnClick(CreateCampaignPages.done);
	  //btnClick_Mat(CreateCampaignPages.detailClick);
	  //btnClick_Mat(CreateCampaignPages.detailClickhome);
	  //pause(2000);
	  //driver.navigate().back();
	  //Home detail navigate
	  //btnClick_Mat(CreateCampaignPages.detailClickhome);*/
	  
  }
	 public void createCampaignfleets_InvalidSheet(){
		  
	  }
  }